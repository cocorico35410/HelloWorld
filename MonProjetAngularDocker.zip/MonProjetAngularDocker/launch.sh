# Extract Application on Host
base64 -d mon-projet-angular.b64 > mon-projet-angular.zip;
unzip mon-projet-angular;


# Build Docker and launch it
docker build -t test_volume .
docker run -it -v $(pwd):/home -p 4200:4200 test_volume
